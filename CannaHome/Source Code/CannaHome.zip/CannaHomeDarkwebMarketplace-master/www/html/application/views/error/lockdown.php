<section>
	<h2 class="centered">We're temporarily down for maintenance. Please try again later.</h2>
	<?php if(!$this->IsForum && 1 == 2){ ?>
	<p class="centered">Meanwhile, check out our <a href="<?php echo $this->ForumURL ? 'http://' . $this->ForumURL : URL . 'forum/'; ?>">forums</a>.</p>
	<?php } ?>
</section>
