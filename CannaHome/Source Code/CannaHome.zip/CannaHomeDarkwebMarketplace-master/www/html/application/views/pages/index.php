<?php if ($this->page && $this->page['content']) { ?>
<div class="formatted">
<?php echo $this->page['content'] ?>
</div>
<?php } ?>