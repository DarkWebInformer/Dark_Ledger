<section class="rows-15">
    <h2 class="row centered"><?php echo '<span class="color-blue">' . $this->errorCode .'!</span> ' . $this->errorDescription ?></h2>
	<p class="row centered"><a href="<?php echo URL ?>">Return Home &#8617;</a></p>
</section>
