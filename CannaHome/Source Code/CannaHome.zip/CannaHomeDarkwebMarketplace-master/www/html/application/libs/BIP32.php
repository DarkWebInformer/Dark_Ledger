<?php

class_alias('BitWasp\BitcoinLib\BIP32', 'BIP32', TRUE);
