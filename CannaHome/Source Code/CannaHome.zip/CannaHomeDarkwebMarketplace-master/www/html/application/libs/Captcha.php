<?php

//require_once(LIBRARY_PATH.'securimage/securimage.php');
require_once(LIBRARY_PATH.'cool-php-captcha/captcha.php');

class Captcha extends SimpleCaptcha{}
