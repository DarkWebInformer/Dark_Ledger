<?php

require_once(LIBRARY_PATH . 'ecc-lib/classes/interface/PointInterface.php');
require_once(LIBRARY_PATH . 'ecc-lib/classes/Point.php');