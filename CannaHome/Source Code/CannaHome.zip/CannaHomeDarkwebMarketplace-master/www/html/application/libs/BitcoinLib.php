<?php


class_alias('BitWasp\BitcoinLib\BitcoinLib', 'BitcoinLib', TRUE);