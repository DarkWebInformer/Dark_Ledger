<?php

require_once(LIBRARY_PATH . 'ecc-lib/classes/interface/PublicKeyInterface.php');
require_once(LIBRARY_PATH . 'ecc-lib/classes/PublicKey.php');