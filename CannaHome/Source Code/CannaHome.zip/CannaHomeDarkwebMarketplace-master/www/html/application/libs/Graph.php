<?php

require_once(LIBRARY_PATH . 'php-graph-lib/PHPGraphLib.php');

class Graph extends PHPGraphLib{}
