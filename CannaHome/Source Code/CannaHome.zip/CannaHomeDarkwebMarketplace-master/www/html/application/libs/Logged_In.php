<?php

/**
 * Class View
 *
 * Provides the methods all views will have
 */
class Logged_In extends View
{
    
}
