<?php

require_once(LIBRARY_PATH . 'php-graph-lib/PHPGraphLib.php');
require_once(LIBRARY_PATH . 'php-graph-lib/PHPGraphLibStacked.php');

class GraphStacked extends PHPGraphLibStacked{}
