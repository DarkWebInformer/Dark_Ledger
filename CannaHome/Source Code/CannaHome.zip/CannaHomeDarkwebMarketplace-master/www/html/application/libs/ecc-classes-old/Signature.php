<?php

require_once(LIBRARY_PATH . 'ecc-lib/classes/interface/SignatureInterface.php');
require_once(LIBRARY_PATH . 'ecc-lib/classes/Signature.php');