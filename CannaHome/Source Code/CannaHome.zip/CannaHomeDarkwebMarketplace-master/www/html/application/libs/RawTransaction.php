<?php

class_alias('BitWasp\BitcoinLib\RawTransaction', 'RawTransaction', TRUE);