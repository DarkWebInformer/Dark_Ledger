<?php

require_once(LIBRARY_PATH . 'ecc-lib/classes/NISTcurve.php');