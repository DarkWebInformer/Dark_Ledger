<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class ServerErrorException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class ServerErrorException extends Exception
{
}
