<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class ResponseEncodingFailureException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class ResponseEncodingFailureException extends Exception
{
}
