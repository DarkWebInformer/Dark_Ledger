<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class InvalidJsonFormatException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class InvalidJsonFormatException extends Exception
{
}
