<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class AccessDeniedException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class AccessDeniedException extends Exception
{
}
