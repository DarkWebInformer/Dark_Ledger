<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class AuthenticationFailureException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class AuthenticationFailureException extends Exception
{
}
