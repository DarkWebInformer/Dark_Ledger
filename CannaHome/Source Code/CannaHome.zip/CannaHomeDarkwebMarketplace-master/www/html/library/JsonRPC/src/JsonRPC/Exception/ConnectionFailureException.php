<?php

namespace JsonRPC\Exception;

use Exception;

/**
 * Class ConnectionFailureException
 *
 * @package JsonRPC\Exception
 * @author  Frederic Guillot
 */
class ConnectionFailureException extends Exception
{
}
