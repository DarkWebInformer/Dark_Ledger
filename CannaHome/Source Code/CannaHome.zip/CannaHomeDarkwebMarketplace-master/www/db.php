<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'home');
define('DB_USER', 'application');
define('DB_PASS', 'lXf8jR6Rsa0CbC5N');
