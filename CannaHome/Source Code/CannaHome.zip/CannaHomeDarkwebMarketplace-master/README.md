Cannahome Marketplace got hacked in November 2019. The owners are trying to hide the hacks so here is the source code and the database of the website.

One thing I don't like is that Dread seems to be protecting some markets. 

See you in hell Yosmite.

Live demo : cannahomeffiw2ca.onion 

contact: SEE YOU IN HELL


In this Github, there is a full source code and the database with all vendors username, chats, orders etc. 
It is encrypted but if you use the private keys that is saved in the users table you can decrypt them.

Database : https://anonfiles.com/V190P7u2o5/fulldump_rar

#Empire is next <'3